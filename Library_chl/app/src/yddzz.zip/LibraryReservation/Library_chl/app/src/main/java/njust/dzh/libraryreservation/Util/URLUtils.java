package njust.dzh.libraryreservation.Util;

public class URLUtils {
    // 励志古言的api（https://www.tianapi.com/apiview/186）
    public static final String APIKEY = "502618e47e2a875ca29c69dacdd65153";
    // 接口地址
    public static String index_url = "http://api.tianapi.com/lzmy/index?key=" + APIKEY;

}
